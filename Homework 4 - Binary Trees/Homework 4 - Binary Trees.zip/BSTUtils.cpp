#include <fstream>
#include "BSTUtils.h"

string* file_to_array(string f_name, int *l)
{
	//implement function

}

void array_to_bst(string key_arr[], int len, BSTree* i_bst)
{
	//implement function

string* presort_array(string in_arr[], int len)
{
	
	//implement function
}